﻿#include <iostream>
#include <fstream>
using namespace std;
#include "listaenlazada.h"
#include <cstring>

bool insertar(tLista &lista, tRegistro registro) { // por el final
   bool ok = true;
   tLista nuevo = new tNodo;
   if (nuevo == NULL)
      ok = false; // no hay más memoria dinámica
   else {
      nuevo->reg = registro;
      nuevo->sig = NULL;
      if (lista == NULL) // lista vacía
         lista = nuevo;
      else {
         tLista p = lista;
         // localizamos el último nodo...
         while (p->sig != NULL)
            p = p->sig;
         p->sig = nuevo;
      }
   }
   return ok;
}

bool eliminar(tLista &lista, int code) {
   bool ok = true;
   tLista p = lista;
   if (p == NULL)
      ok = false; // lista vacía
   else if (p->reg.codigo == code) { // es el primero
      lista = p->sig;
      delete p;
   }
   else {
      tLista ant = p;
      p = p->sig;
      bool encontrado = false;
      while ((p != NULL) && !encontrado)
         if (p->reg.codigo == code)
            encontrado = true;
         else {
            ant = p;
            p = p->sig;
         }
      if (!encontrado)
         ok = false; // no existe ese código
      else {
         ant->sig = p->sig;
         delete p;
      }
   }
   return ok;
}

tLista buscar(tLista lista, int code) {
// Devuelve un puntero al nodo, o NULL si no se encuentra.
   tLista p = lista;
   bool encontrado = false;
   while ((p != NULL) && !encontrado)
      if (p->reg.codigo == code)
         encontrado = true;
      else
         p = p->sig;
   return p;
}

void mostrar(tLista lista) {
   cout << endl
        << "Elementos de la lista:" << endl
        << "----------------------" << endl;
   tLista p = lista;
   while (p != NULL) {
      mostrar(p->reg);
      p = p->sig;
   }
}

bool cargar(tLista &lista) {
   bool ok = true;
   ifstream archivo;
   lista = NULL;
   archivo.open(BD);
   if (!archivo.is_open())
      ok = false;
   else {
      tRegistro registro;
      tLista ult = NULL;
      archivo >> registro.codigo;
      while (registro.codigo != -1) {
         archivo >> registro.valor;
         archivo.getline(registro.nombre, 80);
         if (lista == NULL) {
            lista = new tNodo;
            ult = lista;
         }
         else {
            ult->sig = new tNodo;
            ult = ult->sig;
         }
         ult->reg = registro;
         ult->sig = NULL;
         archivo >> registro.codigo;
      }
      archivo.close();
   }
   return ok;
} 

void guardar(tLista lista) {
   ofstream archivo;
   archivo.open(BD);
   tLista p = lista;
   while (p != NULL) {
      archivo << p->reg.codigo << " ";
      archivo << p->reg.valor;
      archivo << p->reg.nombre << endl;
      p = p->sig;
   }
   archivo << -1 << endl;
   archivo.close();
}

void destruir(tLista &lista) {
   tLista p;
   while (lista != NULL) {
      p = lista;
      lista = lista->sig;
      delete p;
   }
}
