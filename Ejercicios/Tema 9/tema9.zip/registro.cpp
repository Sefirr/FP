﻿#include <iostream>
using namespace std;
#include <iomanip>
#include "registro.h"

tRegistro nuevo() {
   tRegistro reg;
   cout << "Nuevo registro:" << endl;
   cout << "Codigo: "; 
   cin.sync();
   cin >> reg.codigo;
   cout << "Nombre: "; 
   cin.sync();
   cin.getline(reg.nombre, 80);
   cout << "Precio: "; 
   cin.sync();
   cin >> reg.valor;
   return reg;
}

void mostrar(tRegistro registro) {
   cout << setw(10) << registro.codigo << " - " << setw(25) << left
        << registro.nombre << " - " << setw(8) << fixed << right
        << setprecision(2) << registro.valor << " euros" << endl;
}
