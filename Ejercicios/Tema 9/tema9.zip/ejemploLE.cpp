#include <iostream>
using namespace std;
#include "registro.h"
#include "listaenlazada.h"

int main() {
   tLista lista = NULL;
   if (cargar(lista)) {
      mostrar(lista);
      destruir(lista);
   }
   
   return 0;
}

