#include <iostream>
using namespace std;
#include "registro.h"
#include "listaAD.h"

int main() {
   tLista lista;
   if (cargar(lista)) {
      mostrar(lista);
      destruir(lista);
   }
   
   return 0;
}

