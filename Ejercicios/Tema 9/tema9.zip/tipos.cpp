﻿#include <iostream>
using namespace std;

int main() {
   typedef int *intPtr;
   typedef char *charPtr;
   typedef double *doublePtr;
   int entero = 5;
   intPtr puntI = &entero;
   char caracter = 'C';
   charPtr puntC = &caracter;
   double real = 5.23;
   doublePtr puntD = &real;
   cout << *puntI << "   " << *puntC << "   " << *puntD << endl;

   return 0;
}