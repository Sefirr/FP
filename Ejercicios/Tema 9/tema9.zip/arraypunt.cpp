﻿#include <iostream>
using namespace std;

const int MAX = 100;
typedef int tArray[MAX];
typedef struct {
   tArray elementos;
   int cont;
} tLista;
typedef int* intPtr;

bool inserta(tLista &lista, int dato);

int main() {
   tLista lista;
   lista.cont = 0;
   inserta(lista, 4);
   inserta(lista, 13);
   inserta(lista, 3);
   inserta(lista, 47);
   inserta(lista, 53);
   inserta(lista, 19);
   inserta(lista, 7);
   inserta(lista, 48);
   intPtr punt = lista.elementos;
   for (int i = 0; i < lista.cont; i++)
      cout << *punt++ << endl;

   return 0;
}

bool inserta(tLista &lista, int dato) {
   bool ok = true;
   if (lista.cont == MAX)
      ok = false;
   else {
      lista.elementos[lista.cont] = dato;
      lista.cont++;
   }
   return ok;
}
