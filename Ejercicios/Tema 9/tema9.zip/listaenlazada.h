﻿#ifndef LISTAENLAZADA_H
#define LISTAENLAZADA_H

#include "registro.h"

struct tNodo; // Declaración anticipada
typedef tNodo *tLista;
struct tNodo {
   tRegistro reg;
   tLista sig;
};

// Constante global con el nombre del archivo de base de datos:
const char BD[] = "bd.txt";

// Muestra la lista completa.
void mostrar(tLista lista);

// Inserción del registro proporcionado en la lista.
// Devuelve true si se ha podido y false si la lista está llena.
bool insertar(tLista &lista, tRegistro registro);

// Eliminación del registro con el código indicado.
// Devuelve true si se ha podido y false si no está.
bool eliminar(tLista &lista, int code);

// Localiza el registro con ese nombre.
// Devuelve un puntero al nodo, o NULL si no se encuentra.
tLista buscar(tLista lista, int code);

// Carga los datos del archivo de base de datos en la lista.
bool cargar(tLista &lista);

// Guarda los datos de la lista en el archivo de base de datos.
void guardar(tLista lista);

// Destruir todas las variables dinámicas.
void destruir(tLista &lista);

#endif
