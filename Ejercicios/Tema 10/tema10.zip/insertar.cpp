﻿#include <iostream>
using namespace std;
#include <fstream>
#include "registro.h"

const char BD[] = "ord2.dat";

void mostrar();

void mostrar() {
   tRegistro registro;
   fstream archivo;
   archivo.open(BD, ios::in | ios::binary);
   archivo.seekg(0, ios::end);
   int pos = archivo.tellg();
   int numReg = pos / SIZE;
   archivo.seekg(0, ios::beg);
   archivo.read( (char *) &registro, SIZE);
   int cuantos = archivo.gcount();
   cout << "------------" << endl;
   while (cuantos == SIZE) {
      mostrar(registro);
      archivo.read( (char *) &registro, SIZE);
      cuantos = archivo.gcount();
   }
   cout << "------------" << endl;
   archivo.close();
}

int main() {
   mostrar();
   tRegistro nuevoRegistro = nuevo(), registro;
   fstream archivo;
   archivo.open(BD, ios::in | ios::out | ios::binary);
   archivo.seekg(0, ios::end);
   int pos = archivo.tellg();
   int numReg = pos / SIZE;
   pos = 0;
   bool encontrado = false;
   archivo.seekg(0, ios::beg);
   while ((pos < numReg) && !encontrado) {
      archivo.read( (char *) &registro, SIZE);
      if (registro.codigo > nuevoRegistro.codigo)
         encontrado = true;
      else 
         pos++;
   }
   if (pos == numReg) { // Debe ir al final
      archivo.seekg(0, ios::end);
      archivo.write( (char *) &nuevoRegistro, SIZE);
   }
   else {
      // Hay que hacer hueco
      for (int i = numReg - 1; i >= pos; i--) {
         archivo.seekg(i * SIZE, ios::beg);
         archivo.read( (char *) &registro, SIZE);
         archivo.seekg((i + 1) * SIZE, ios::beg);
         archivo.write( (char *) &registro, SIZE);
      }
      archivo.seekg(pos * SIZE, ios::beg);
      archivo.write( (char *) &nuevoRegistro, SIZE);
   }
   archivo.close();
   
   mostrar();

   return 0;
}
