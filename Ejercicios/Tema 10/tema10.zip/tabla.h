﻿#ifndef TABLA_H
#define TABLA_H

#include "registro.h"

const int N = 100;

// Array de registros:
typedef tRegistro tLista[N];

// Tabla: array y contador
typedef struct {
   tLista registros;
   int cont;
} tTabla;

// Constante global con el nombre del archivo de base de datos:
const char BD[] = "bd.dat";

// Muestra la tabla completa.
void mostrar(const tTabla &tabla);

// Inserción del registro proporcionado en la tabla.
// Devuelve true si se ha podido y false si la tabla está llena.
bool insertar(tTabla &tabla, tRegistro registro);

// Eliminación del registro en la posición indicada.
// Devuelve true si se ha podido y false si la posición no es válida.
bool eliminar(tTabla &tabla, int code); // pos = 1..N

// Localiza el registro con ese nombre.
// Devuelve el índice, o -1 si no se encuentra.
int buscar(tTabla tabla, int code);

// Carga los datos del archivo de base de datos en la tabla.
bool cargar(tTabla &tabla);

// Guarda los datos de la tabla en el archivo de base de datos.
void guardar(tTabla tabla);

#endif
