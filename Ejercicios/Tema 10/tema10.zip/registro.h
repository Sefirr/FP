﻿#ifndef REGISTRO_H
#define REGISTRO_H

typedef char tCadena[80];

// Estructura para los datos de cada registro:
typedef struct {
   int codigo;
   tCadena item;
   double valor;
} tRegistro;

const int SIZE = sizeof(tRegistro);

// Lectura de los datos de un nuevo registro.
tRegistro nuevo();

// Muestra en una línea la información del registro proporcionado.
void mostrar(tRegistro registro);

#endif
