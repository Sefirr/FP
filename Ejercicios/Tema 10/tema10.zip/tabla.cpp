﻿#include <iostream>
#include <fstream>
using namespace std;
#include "tabla.h"
#include <cstring>

bool insertar(tTabla &tabla, tRegistro registro) {
   bool ok = true;
   if (tabla.cont == N)
      ok = false; // tabla llena
   else {
      tabla.registros[tabla.cont] = registro;
      tabla.cont++;
   }
   return ok;
}

bool eliminar(tTabla &tabla, int code) { // pos = 1..
   bool ok = true;
   int pos = buscar(tabla, code);
   if (pos == -1)
      ok = false;
   else {
      for (int i = pos + 1; i < tabla.cont; i++) // Desplazamos una posición a la izquierda
         tabla.registros[i-1] = tabla.registros[i];
      tabla.cont--;
   }
   return ok;
}

int buscar(tTabla tabla, int code) {
// Devuelve -1 si no se ha encontrado
   int pos = 0;
   bool encontrado = false;
   while ((pos < tabla.cont) && !encontrado) {
      if (tabla.registros[pos].codigo == code)
         encontrado = true;
      else
         pos++;
   }
   if (!encontrado)
      pos = -1;
   return pos;
}

void mostrar(const tTabla &tabla) {
   cout << endl
        << "Elementos de la lista:" << endl
        << "----------------------" << endl;
   for (int i = 0; i < tabla.cont; i++)
      mostrar(tabla.registros[i]);
}

bool cargar(tTabla &tabla) {
   bool ok = true;
   fstream archivo;
   tabla.cont = 0;
   archivo.open(BD, ios::in | ios::binary);
   if (!archivo.is_open())
      ok = false;
   else {
      archivo.seekg(0, ios::end);
      int pos = archivo.tellg();
      int numReg = pos / SIZE;
      tabla.cont = 0;
      tRegistro registro;
      archivo.seekg(0, ios::beg);
      for (int i = 0; i < numReg; i++) {
         archivo.read( (char *) &registro, sizeof(tRegistro));
         tabla.registros[tabla.cont] = registro;
         tabla.cont++;
      }
      archivo.close();
   }
   return ok;
} 

void guardar(tTabla tabla) {
   fstream archivo;
   archivo.open(BD, ios::out | ios::binary | ios::trunc);
   for (int i = 0; i < tabla.cont; i++)
      archivo.write( (char *) &tabla.registros[i], SIZE);
   archivo.close();
}
