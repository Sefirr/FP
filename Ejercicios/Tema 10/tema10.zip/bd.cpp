﻿#include <iostream>
using namespace std;
#include "registro.h"
#include "tabla.h"

int main() {
   tTabla tabla;

   if (!cargar(tabla))
      cout << "Error al abrir el archivo!" << endl;
   else {
      mostrar(tabla);
      tRegistro registro = nuevo();
      insertar(tabla, registro);
      mostrar(tabla);
      guardar(tabla);
   }
   
   return 0;
}
