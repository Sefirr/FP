﻿#include <iostream>
using namespace std;
#include <fstream>
#include <iomanip>
#include <cstring>
#include "registro.h"

const char BD[] = "lista.dat";

void mostrar();

void mostrar() {
   fstream archivo;
   tRegistro registro;
   int cuantos;
   archivo.open(BD, ios::in | ios::binary);
   archivo.read( (char *) &registro, SIZE);
   cuantos = archivo.gcount();
   while (cuantos == SIZE) {
      mostrar(registro);
      archivo.read( (char *) &registro, SIZE);
      cuantos = archivo.gcount();
   }
   archivo.close();
}

int main() {

   mostrar();

   fstream archivo;
   archivo.open(BD, ios::in | ios::out | ios::binary);
   archivo.seekg(0, ios::end);
   int pos = archivo.tellg();
   int numReg = pos / SIZE;

   // Ordenamos con el método de selección directa
   tRegistro regMenor, reg;
   for (int i = 0; i < numReg - 1; i++) {
      int menor = i;
      for (int j = i + 1; j < numReg; j++) {
         archivo.seekg(menor * SIZE, ios::beg);
         archivo.read( (char *) &regMenor, SIZE);
         archivo.seekg(j * SIZE, ios::beg);
         archivo.read( (char *) &reg, SIZE);
         if (strcmp(reg.item, regMenor.item) < 0)
            menor = j;
//         if (reg.codigo < regMenor.codigo) menor = j;
      }
      if (menor > i) { // Intercambiamos
         archivo.seekg(menor * SIZE, ios::beg);
         archivo.read( (char *) &regMenor, SIZE);
         archivo.seekg(i * SIZE, ios::beg);
         archivo.read( (char *) &reg, SIZE);
         archivo.seekg(menor * SIZE, ios::beg);
         archivo.write( (char *) &reg, SIZE);
         archivo.seekg(i * SIZE, ios::beg);
         archivo.write( (char *) &regMenor, SIZE);
      }
   }
   archivo.close();
   
   cout << endl << "Tras ordenar:" << endl << endl;
   mostrar();

   return 0;
}
