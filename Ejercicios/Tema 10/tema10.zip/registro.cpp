﻿#include <iostream>
using namespace std;
#include <iomanip>
#include "registro.h"

tRegistro nuevo() {
   tRegistro reg;
   cout << "Nuevo registro:" << endl;
   cout << "Codigo: "; 
   cin >> reg.codigo;
   cin.ignore();
   cout << "Nombre: "; 
   cin.getline(reg.item, 80);
   cout << "Precio: "; 
   cin >> reg.valor;
   cin.ignore();
   return reg;
}

void mostrar(tRegistro registro) {
   cout << setw(10) << registro.codigo << " - " << setw(30) << left
        << registro.item << " - " << setw(8) << fixed << right
        << setprecision(2) << registro.valor << " euros" << endl;
}
