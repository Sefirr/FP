﻿#include <iostream>
using namespace std;
#include <fstream>
#include "registro.h"

const char BD[] = "ord.dat";

void mostrar();

void mostrar() {
   tRegistro registro;
   fstream archivo;
   archivo.open(BD, ios::in | ios::binary);
   archivo.seekg(0, ios::end);
   int pos = archivo.tellg();
   int numReg = pos / SIZE;
   archivo.seekg(0, ios::beg);
   archivo.read( (char *) &registro, SIZE);
   int cuantos = archivo.gcount();
   cout << "------------" << endl;
   while (cuantos == SIZE) {
      mostrar(registro);
      archivo.read( (char *) &registro, SIZE);
      cuantos = archivo.gcount();
   }
   cout << "------------" << endl;
   archivo.close();
}

int main() {
   mostrar();
   tRegistro registro;
   fstream archivo;
   archivo.open(BD, ios::in | ios::binary);
   archivo.seekg(0, ios::end);
   int pos = archivo.tellg();
   int numReg = pos / SIZE;
   int buscado;
   cout << "Codigo a buscar: ";
   cin >> buscado;
   int ini = 0, fin = numReg - 1, mitad;
   bool encontrado = false;
   while ((ini <= fin) && !encontrado) {
      mitad = (ini + fin) / 2; // División entera
      // leemos el elemento en mitad
      archivo.seekg(mitad * SIZE, ios::beg);
      archivo.read( (char *) &registro, SIZE);
      if (buscado == registro.codigo)
         encontrado = true;
      else if (buscado < registro.codigo)
         fin = mitad - 1;
      else
         ini = mitad + 1;
   }
   if (encontrado) {
      int pos = mitad + 1;
      cout << "Encontrado en la posicion " << pos << endl;
      mostrar(registro);
   }
   else
      cout << "No encontrado" << endl;
   
   archivo.close();

   return 0;
}
