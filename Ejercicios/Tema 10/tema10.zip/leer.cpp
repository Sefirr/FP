﻿#include <iostream>
using namespace std;
#include <fstream>
#include "registro.h"

int main() {
   tRegistro registro;
   fstream archivo;
   archivo.open("bd.dat", ios::in | ios::binary);
   archivo.read( (char *) &registro, SIZE);
   int cuantos = archivo.gcount();
   while (cuantos == SIZE) {
      mostrar(registro);
      archivo.read( (char *) &registro, SIZE);
      cuantos = archivo.gcount();
   }
   archivo.close();

   return 0;
}
