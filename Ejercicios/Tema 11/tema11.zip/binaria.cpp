﻿#include <iostream>
#include <fstream>
using namespace std;

const int N = 100;
typedef int tArray[N];
typedef struct {
   tArray elementos;
   int cont;
} tLista;

// Devuelve la posición del elemento buscado (1, ...) o -1 si no se encuentra
int buscar(tLista lista, int buscado, int ini, int fin);

int main() {
   tLista lista;
   lista.cont = 0;
   ifstream archivo;
   archivo.open("enteros.txt"); // Existe y es correcto
   int dato;
   while (archivo >> dato) {
      lista.elementos[lista.cont] = dato;
      lista.cont++;
   }
   for (int i = 0; i < lista.cont; i++)
      cout << lista.elementos[i] << "   ";
   cout << endl;
   int buscado, pos;
   cout << "Valor a buscar: "; cin >> buscado;
   pos = buscar(lista, buscado, 0, lista.cont - 1);
   if (pos == -1)
      cout << "No encontrado!" << endl;
   else
      cout << "Encontrado en la posicion " << pos + 1 << endl;
   
   return 0;
}

int buscar(tLista lista, int buscado, int ini, int fin) {
   int pos = -1;
   if (ini <= fin) {
      int mitad = (ini + fin) / 2;
      if (buscado == lista.elementos[mitad])
         return pos = mitad;
      else if (buscado < lista.elementos[mitad])
         pos = buscar(lista, buscado, ini, mitad - 1);
      else
         pos = buscar(lista, buscado, mitad + 1, fin);
   }
   return pos;
}
