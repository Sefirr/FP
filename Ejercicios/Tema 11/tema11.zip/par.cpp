﻿#include <iostream>
using namespace std;

bool par(int n);
bool impar(int n);

bool par(int n) {
   if (n == 0) return true;
   else return impar(n - 1);
}
bool impar(int n) {
   if (n == 0) return false;
   else return par(n - 1);
}
int main() {
   int x;
   cout << "Num: "; cin >> x;
   if (par(x)) cout << "Es par";
   else cout << "Es impar";

   return 0;
}
