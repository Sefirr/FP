﻿#include <iostream>
#include <fstream>
using namespace std;

const int N = 100;
typedef int tArray[N];
typedef struct {
   tArray elementos;
   int cont;
} tLista;

void mostrar(tLista lista, int pos);

int main() {
   tLista lista;
   lista.cont = 0;
   ifstream archivo;
   archivo.open("enteros.txt"); // Existe y es correcto
   int dato;
   while (archivo >> dato) {
      lista.elementos[lista.cont] = dato;
      lista.cont++;
   }
   mostrar(lista, 0);
   
   return 0;
}

void mostrar(tLista lista, int pos) {
   if (pos < lista.cont) {
      cout << lista.elementos[pos] << endl;
      mostrar(lista, pos + 1);
   }
}
